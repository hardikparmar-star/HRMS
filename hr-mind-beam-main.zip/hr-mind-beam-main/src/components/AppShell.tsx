import { Link, Outlet, useLocation, useNavigate } from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { useAuth } from "@/hooks/useAuth";
import { LayoutDashboard, Users, Clock, CalendarDays, Wallet, FileText, LogOut, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard; adminOnly?: boolean };
const nav: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/employees", label: "Employees", icon: Users, adminOnly: true },
  { to: "/attendance", label: "Attendance", icon: Clock },
  { to: "/leaves", label: "Leaves", icon: CalendarDays },
  { to: "/payroll", label: "Payroll", icon: Wallet, adminOnly: true },
  { to: "/payslips", label: "Salary Slips", icon: FileText },
];

export function AppShell({ children }: { children?: ReactNode }) {
  const { user, role, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/login" });
  }, [loading, user, navigate]);

  if (loading || !user) {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 flex-col gradient-sidebar p-4 text-sidebar-foreground md:flex">
        <Link to="/dashboard" className="mb-8 flex items-center gap-2 px-2">
          <div className="size-9 rounded-xl bg-white/15" />
          <span className="font-display text-lg font-bold">Pulse HR</span>
        </Link>
        <nav className="flex-1 space-y-1">
          {nav.filter((n) => !n.adminOnly || role === "admin").map((n) => {
            const active = location.pathname.startsWith(n.to);
            return (
              <Link key={n.to} to={n.to}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
                )}>
                <n.icon className="size-4" /> {n.label}
              </Link>
            );
          })}
        </nav>
        <div className="space-y-1 border-t border-sidebar-border pt-3">
          <div className="px-3 py-2 text-xs">
            <div className="truncate font-medium text-sidebar-foreground">{user.email}</div>
            <div className="text-sidebar-foreground/60 capitalize">{role ?? "—"}</div>
          </div>
          <button onClick={() => signOut()} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/80 hover:bg-sidebar-accent/60">
            <LogOut className="size-4" /> Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-x-hidden">
        <header className="flex items-center justify-between border-b bg-card/60 px-6 py-3 backdrop-blur md:py-4">
          <div className="md:hidden">
            <span className="font-display font-bold">Pulse HR</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="ghost" size="icon" aria-label="Settings"><Settings className="size-4" /></Button>
          </div>
        </header>
        <div className="p-6">{children ?? <Outlet />}</div>
      </main>
    </div>
  );
}
