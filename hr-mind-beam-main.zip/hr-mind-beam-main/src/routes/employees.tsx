import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/employees")({ component: () => <AppShell><EmployeesPage /></AppShell> });

function EmployeesPage() {
  const qc = useQueryClient();
  const { role } = useAuth();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const isAdmin = role === "admin";

  const { data: employees = [] } = useQuery({
    queryKey: ["employees"],
    queryFn: async () => {
      const { data, error } = await supabase.from("employees").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const filtered = employees.filter((e) => `${e.full_name} ${e.email} ${e.employee_code} ${e.department ?? ""}`.toLowerCase().includes(q.toLowerCase()));

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const obj: Record<string, unknown> = {};
    fd.forEach((v, k) => { obj[k] = v === "" ? null : v; });
    ["basic_salary", "hra", "conveyance", "medical", "special_allowance"].forEach((k) => { obj[k] = Number(obj[k] ?? 0); });
    const { error } = await supabase.from("employees").insert(obj as never);
    if (error) return toast.error(error.message);
    toast.success("Employee added");
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["employees"] });
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this employee?")) return;
    const { error } = await supabase.from("employees").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: ["employees"] });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Employees</h1>
          <p className="text-sm text-muted-foreground">{employees.length} total</p>
        </div>
        {isAdmin && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" /> Add employee</Button></DialogTrigger>
            <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
              <DialogHeader><DialogTitle>New employee</DialogTitle></DialogHeader>
              <form onSubmit={onSubmit} className="grid grid-cols-2 gap-4">
                {[
                  ["full_name", "Full name", true], ["email", "Email", true],
                  ["phone", "Phone"], ["department", "Department"],
                  ["designation", "Designation"], ["joining_date", "Joining date", false, "date"],
                  ["pan_number", "PAN"], ["aadhaar_number", "Aadhaar"],
                  ["uan_number", "UAN"], ["reporting_manager", "Reporting manager"],
                  ["bank_name", "Bank name"], ["bank_account", "Account #"],
                  ["bank_ifsc", "IFSC"],
                  ["basic_salary", "Basic", false, "number"], ["hra", "HRA", false, "number"],
                  ["conveyance", "Conveyance", false, "number"], ["medical", "Medical", false, "number"],
                  ["special_allowance", "Special allowance", false, "number"],
                ].map(([name, label, req, type]) => (
                  <div key={name as string} className={name === "full_name" || name === "email" ? "col-span-2" : ""}>
                    <Label htmlFor={name as string}>{label as string}</Label>
                    <Input id={name as string} name={name as string} type={(type as string) || "text"} required={Boolean(req)} />
                  </div>
                ))}
                <DialogFooter className="col-span-2"><Button type="submit">Save employee</Button></DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="rounded-2xl border bg-card shadow-card">
        <div className="flex items-center gap-2 border-b p-3">
          <Search className="size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, email, code, department" className="border-0 shadow-none focus-visible:ring-0" />
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead><TableHead>Name</TableHead><TableHead>Email</TableHead>
              <TableHead>Department</TableHead><TableHead>Designation</TableHead>
              <TableHead className="text-right">CTC (Basic)</TableHead>
              {isAdmin && <TableHead></TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((e) => (
              <TableRow key={e.id}>
                <TableCell className="font-mono text-xs">{e.employee_code}</TableCell>
                <TableCell className="font-medium">{e.full_name}</TableCell>
                <TableCell className="text-muted-foreground">{e.email}</TableCell>
                <TableCell>{e.department}</TableCell>
                <TableCell>{e.designation}</TableCell>
                <TableCell className="text-right">₹{Number(e.basic_salary).toLocaleString("en-IN")}</TableCell>
                {isAdmin && (
                  <TableCell><Button size="icon" variant="ghost" onClick={() => remove(e.id)}><Trash2 className="size-4 text-destructive" /></Button></TableCell>
                )}
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={isAdmin ? 7 : 6} className="py-12 text-center text-muted-foreground">No employees found.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
