import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Users, Clock, CalendarDays, Wallet } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, PieChart, Pie, Cell, CartesianGrid } from "recharts";

export const Route = createFileRoute("/dashboard")({ component: () => <AppShell><Dashboard /></AppShell> });

function Stat({ icon: Icon, label, value, accent }: { icon: typeof Users; label: string; value: string | number; accent: string }) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-card">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <span className={`inline-flex size-9 items-center justify-center rounded-xl ${accent}`}><Icon className="size-4" /></span>
      </div>
      <div className="mt-3 font-display text-3xl font-bold">{value}</div>
    </div>
  );
}

function Dashboard() {
  const { data } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const today = new Date().toISOString().slice(0, 10);
      const [emp, att, lv, pay] = await Promise.all([
        supabase.from("employees").select("id, department", { count: "exact" }),
        supabase.from("attendance").select("id, status", { count: "exact" }).eq("date", today),
        supabase.from("leaves").select("id", { count: "exact" }).eq("status", "pending"),
        supabase.from("payslips").select("net_pay"),
      ]);
      const deptMap: Record<string, number> = {};
      (emp.data ?? []).forEach((e) => { const d = e.department || "Unassigned"; deptMap[d] = (deptMap[d] ?? 0) + 1; });
      const dept = Object.entries(deptMap).map(([name, value]) => ({ name, value }));
      const totalNet = (pay.data ?? []).reduce((s, p) => s + Number(p.net_pay), 0);
      return {
        employees: emp.count ?? 0,
        present: (att.data ?? []).filter((a) => a.status === "present").length,
        pendingLeaves: lv.count ?? 0,
        totalNet,
        dept,
      };
    },
  });

  const colors = ["oklch(0.52 0.18 265)", "oklch(0.68 0.19 285)", "oklch(0.68 0.16 155)", "oklch(0.78 0.16 75)", "oklch(0.6 0.22 25)"];
  const trend = Array.from({ length: 6 }).map((_, i) => ({
    month: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"][i],
    hires: Math.floor(2 + Math.random() * 6),
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Overview of your organization at a glance.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Stat icon={Users} label="Total Employees" value={data?.employees ?? 0} accent="bg-primary/10 text-primary" />
        <Stat icon={Clock} label="Present Today" value={data?.present ?? 0} accent="bg-success/10 text-success" />
        <Stat icon={CalendarDays} label="Pending Leaves" value={data?.pendingLeaves ?? 0} accent="bg-warning/10 text-warning" />
        <Stat icon={Wallet} label="Payroll YTD" value={`₹${(data?.totalNet ?? 0).toLocaleString("en-IN")}`} accent="bg-accent text-accent-foreground" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border bg-card p-5 shadow-card lg:col-span-2">
          <h3 className="font-semibold">Hiring trend</h3>
          <div className="mt-4 h-64">
            <ResponsiveContainer>
              <BarChart data={trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0.008 260)" />
                <XAxis dataKey="month" stroke="oklch(0.5 0.02 260)" fontSize={12} />
                <YAxis stroke="oklch(0.5 0.02 260)" fontSize={12} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid oklch(0.92 0.008 260)" }} />
                <Bar dataKey="hires" fill="oklch(0.52 0.18 265)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-2xl border bg-card p-5 shadow-card">
          <h3 className="font-semibold">By department</h3>
          <div className="mt-4 h-64">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={data?.dept ?? []} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={3}>
                  {(data?.dept ?? []).map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 space-y-1 text-sm">
            {(data?.dept ?? []).slice(0, 5).map((d, i) => (
              <div key={d.name} className="flex items-center justify-between">
                <span className="flex items-center gap-2"><span className="size-2 rounded-full" style={{ background: colors[i % colors.length] }} /> {d.name}</span>
                <span className="text-muted-foreground">{d.value}</span>
              </div>
            ))}
            {(!data?.dept || data.dept.length === 0) && <p className="text-muted-foreground">No employees yet.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
