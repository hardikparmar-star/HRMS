import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { Clock, LogIn, LogOut } from "lucide-react";

export const Route = createFileRoute("/attendance")({ component: () => <AppShell><AttendancePage /></AppShell> });

function AttendancePage() {
  const qc = useQueryClient();
  const { user, role } = useAuth();

  const { data: myEmployee } = useQuery({
    queryKey: ["my-employee", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("employees").select("*").eq("user_id", user!.id).maybeSingle();
      return data;
    },
  });

  const { data: records = [] } = useQuery({
    queryKey: ["attendance", role, myEmployee?.id],
    queryFn: async () => {
      let q = supabase.from("attendance").select("*, employees(full_name, employee_code)").order("date", { ascending: false }).limit(50);
      if (role !== "admin" && myEmployee) q = q.eq("employee_id", myEmployee.id);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });

  const today = new Date().toISOString().slice(0, 10);
  const todayRecord = records.find((r) => r.date === today && r.employee_id === myEmployee?.id);

  const checkIn = async () => {
    if (!myEmployee) return toast.error("No employee profile linked. Ask admin.");
    const { error } = await supabase.from("attendance").insert({ employee_id: myEmployee.id, date: today, check_in: new Date().toISOString(), status: "present" });
    if (error) return toast.error(error.message);
    toast.success("Checked in");
    qc.invalidateQueries({ queryKey: ["attendance"] });
  };

  const checkOut = async () => {
    if (!todayRecord) return;
    const start = new Date(todayRecord.check_in!);
    const hours = Math.max(0, (Date.now() - start.getTime()) / 3_600_000);
    const { error } = await supabase.from("attendance").update({ check_out: new Date().toISOString(), hours_worked: Number(hours.toFixed(2)) }).eq("id", todayRecord.id);
    if (error) return toast.error(error.message);
    toast.success("Checked out");
    qc.invalidateQueries({ queryKey: ["attendance"] });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Attendance</h1>
          <p className="text-sm text-muted-foreground">Daily check-in tracking</p>
        </div>
        {myEmployee && (
          <div className="flex items-center gap-2">
            {!todayRecord?.check_in && <Button onClick={checkIn} className="gap-2"><LogIn className="size-4" /> Check in</Button>}
            {todayRecord?.check_in && !todayRecord.check_out && <Button onClick={checkOut} variant="outline" className="gap-2"><LogOut className="size-4" /> Check out</Button>}
            {todayRecord?.check_out && <span className="inline-flex items-center gap-2 rounded-full bg-success/10 px-3 py-1.5 text-sm text-success"><Clock className="size-3" /> Done for today</span>}
          </div>
        )}
      </div>

      <div className="rounded-2xl border bg-card shadow-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              {role === "admin" && <TableHead>Employee</TableHead>}
              <TableHead>Check in</TableHead><TableHead>Check out</TableHead>
              <TableHead>Hours</TableHead><TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {records.map((r) => (
              <TableRow key={r.id}>
                <TableCell>{r.date}</TableCell>
                {role === "admin" && <TableCell>{r.employees?.full_name}</TableCell>}
                <TableCell>{r.check_in ? new Date(r.check_in).toLocaleTimeString() : "—"}</TableCell>
                <TableCell>{r.check_out ? new Date(r.check_out).toLocaleTimeString() : "—"}</TableCell>
                <TableCell>{r.hours_worked ?? 0}</TableCell>
                <TableCell><span className="rounded-full bg-success/10 px-2 py-0.5 text-xs text-success capitalize">{r.status}</span></TableCell>
              </TableRow>
            ))}
            {records.length === 0 && <TableRow><TableCell colSpan={role === "admin" ? 6 : 5} className="py-12 text-center text-muted-foreground">No records yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
