import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useState } from "react";
import { toast } from "sonner";
import { Lock, Play, FileDown } from "lucide-react";
import { generatePayslipPDF } from "@/lib/payslip";

export const Route = createFileRoute("/payroll")({ component: () => <AppShell><PayrollPage /></AppShell> });

const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function PayrollPage() {
  const qc = useQueryClient();
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());

  const { data: runs = [] } = useQuery({
    queryKey: ["payroll-runs"],
    queryFn: async () => (await supabase.from("payroll_runs").select("*").order("period_year", { ascending: false }).order("period_month", { ascending: false })).data ?? [],
  });

  const processPayroll = async () => {
    const { data: employees } = await supabase.from("employees").select("*").eq("status", "active");
    if (!employees || employees.length === 0) return toast.error("No active employees");

    const { data: run, error: runErr } = await supabase.from("payroll_runs")
      .upsert({ period_month: month, period_year: year, status: "processed", processed_at: new Date().toISOString() }, { onConflict: "period_month,period_year" })
      .select().single();
    if (runErr || !run) return toast.error(runErr?.message ?? "Failed");

    // Compute leave deductions for the month
    const monthStart = `${year}-${String(month).padStart(2, "0")}-01`;
    const monthEnd = new Date(year, month, 0).toISOString().slice(0, 10);
    const { data: leaves } = await supabase.from("leaves").select("employee_id, days").eq("status", "approved").gte("start_date", monthStart).lte("end_date", monthEnd);
    const leaveMap: Record<string, number> = {};
    (leaves ?? []).forEach((l) => { leaveMap[l.employee_id] = (leaveMap[l.employee_id] ?? 0) + Number(l.days); });

    const workingDays = 30;
    const slips = employees.map((e) => {
      const leaveDays = Math.min(workingDays, leaveMap[e.id] ?? 0);
      const paidDays = workingDays - leaveDays;
      const factor = paidDays / workingDays;
      const basic = Number(e.basic_salary) * factor;
      const hra = Number(e.hra) * factor;
      const conveyance = Number(e.conveyance) * factor;
      const medical = Number(e.medical) * factor;
      const special = Number(e.special_allowance) * factor;
      const bonus = 0;
      const gross = basic + hra + conveyance + medical + special + bonus;
      const pf = Math.min(basic * 0.12, 1800);
      const esic = gross < 21000 ? gross * 0.0075 : 0;
      const pt = gross > 15000 ? 200 : 0;
      const tds = gross > 50000 ? gross * 0.05 : 0;
      const leaveDeduction = (Number(e.basic_salary) / workingDays) * leaveDays * 0;
      const totalDed = pf + esic + pt + tds + leaveDeduction;
      return {
        payroll_run_id: run.id, employee_id: e.id, working_days: workingDays, paid_days: paidDays,
        basic, hra, conveyance, medical, special_allowance: special, bonus,
        pf, esic, pt, tds, leave_deduction: leaveDeduction,
        gross, total_deductions: totalDed, net_pay: gross - totalDed,
      };
    });

    const { error: insErr } = await supabase.from("payslips").upsert(slips, { onConflict: "payroll_run_id,employee_id" });
    if (insErr) return toast.error(insErr.message);

    const totalNet = slips.reduce((s, p) => s + p.net_pay, 0);
    await supabase.from("payroll_runs").update({ total_net: totalNet }).eq("id", run.id);
    toast.success(`Processed ${slips.length} payslips`);
    qc.invalidateQueries({ queryKey: ["payroll-runs"] });
  };

  const lockRun = async (id: string) => {
    await supabase.from("payroll_runs").update({ status: "locked" }).eq("id", id);
    toast.success("Payroll locked");
    qc.invalidateQueries({ queryKey: ["payroll-runs"] });
  };

  const downloadAll = async (runId: string) => {
    const { data } = await supabase.from("payslips").select("*, payroll_runs(period_month, period_year), employees(*)").eq("payroll_run_id", runId);
    (data ?? []).forEach((p) => generatePayslipPDF(p as never));
    toast.success(`Generated ${data?.length ?? 0} slips`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold">Payroll</h1>
        <p className="text-sm text-muted-foreground">Process monthly payroll and generate payslips.</p>
      </div>

      <div className="rounded-2xl border bg-card p-5 shadow-card">
        <h3 className="font-semibold">Run payroll</h3>
        <div className="mt-4 flex flex-wrap items-end gap-3">
          <div>
            <div className="mb-1 text-xs text-muted-foreground">Month</div>
            <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
              <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
              <SelectContent>{months.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <div className="mb-1 text-xs text-muted-foreground">Year</div>
            <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
              <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
              <SelectContent>{[year - 1, year, year + 1].map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <Button onClick={processPayroll} className="gap-2"><Play className="size-4" /> Process payroll</Button>
        </div>
      </div>

      <div className="rounded-2xl border bg-card shadow-card">
        <Table>
          <TableHeader>
            <TableRow><TableHead>Period</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Total net</TableHead><TableHead></TableHead></TableRow>
          </TableHeader>
          <TableBody>
            {runs.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="font-medium">{months[r.period_month - 1]} {r.period_year}</TableCell>
                <TableCell><span className="rounded-full bg-success/10 px-2 py-0.5 text-xs text-success capitalize">{r.status}</span></TableCell>
                <TableCell className="text-right">₹{Number(r.total_net).toLocaleString("en-IN")}</TableCell>
                <TableCell className="space-x-2 text-right">
                  <Button size="sm" variant="outline" onClick={() => downloadAll(r.id)} className="gap-2"><FileDown className="size-3.5" /> Slips</Button>
                  {r.status !== "locked" && <Button size="sm" variant="ghost" onClick={() => lockRun(r.id)} className="gap-2"><Lock className="size-3.5" /> Lock</Button>}
                </TableCell>
              </TableRow>
            ))}
            {runs.length === 0 && <TableRow><TableCell colSpan={4} className="py-12 text-center text-muted-foreground">No payroll runs yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
