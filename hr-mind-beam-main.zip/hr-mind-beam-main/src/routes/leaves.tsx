import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { Plus, Check, X } from "lucide-react";

export const Route = createFileRoute("/leaves")({ component: () => <AppShell><LeavesPage /></AppShell> });

function LeavesPage() {
  const qc = useQueryClient();
  const { user, role } = useAuth();
  const [open, setOpen] = useState(false);

  const { data: myEmployee } = useQuery({
    queryKey: ["my-employee", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("employees").select("id, full_name").eq("user_id", user!.id).maybeSingle()).data,
  });

  const { data: leaves = [] } = useQuery({
    queryKey: ["leaves", role, myEmployee?.id],
    queryFn: async () => {
      let q = supabase.from("leaves").select("*, employees(full_name, employee_code)").order("created_at", { ascending: false });
      if (role !== "admin" && myEmployee) q = q.eq("employee_id", myEmployee.id);
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!myEmployee) return toast.error("No employee profile linked.");
    const fd = new FormData(e.currentTarget);
    const start = String(fd.get("start_date"));
    const end = String(fd.get("end_date"));
    const days = Math.max(1, Math.round((+new Date(end) - +new Date(start)) / 86_400_000) + 1);
    const { error } = await supabase.from("leaves").insert({
      employee_id: myEmployee.id, leave_type: String(fd.get("leave_type")),
      start_date: start, end_date: end, days, reason: String(fd.get("reason") || ""),
    });
    if (error) return toast.error(error.message);
    toast.success("Leave requested");
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["leaves"] });
  };

  const decide = async (id: string, status: "approved" | "rejected") => {
    const { error } = await supabase.from("leaves").update({ status, approved_by: user!.id }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Leave ${status}`);
    qc.invalidateQueries({ queryKey: ["leaves"] });
  };

  const statusColor: Record<string, string> = {
    pending: "bg-warning/10 text-warning",
    approved: "bg-success/10 text-success",
    rejected: "bg-destructive/10 text-destructive",
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold">Leaves</h1>
          <p className="text-sm text-muted-foreground">Requests and approvals</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" /> Request leave</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New leave request</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-4">
              <div>
                <Label>Type</Label>
                <Select name="leave_type" defaultValue="casual">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="sick">Sick</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label htmlFor="start_date">Start</Label><Input id="start_date" name="start_date" type="date" required /></div>
                <div><Label htmlFor="end_date">End</Label><Input id="end_date" name="end_date" type="date" required /></div>
              </div>
              <div><Label htmlFor="reason">Reason</Label><Textarea id="reason" name="reason" /></div>
              <DialogFooter><Button type="submit">Submit</Button></DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-2xl border bg-card shadow-card">
        <Table>
          <TableHeader>
            <TableRow>
              {role === "admin" && <TableHead>Employee</TableHead>}
              <TableHead>Type</TableHead><TableHead>From</TableHead><TableHead>To</TableHead>
              <TableHead>Days</TableHead><TableHead>Reason</TableHead><TableHead>Status</TableHead>
              {role === "admin" && <TableHead></TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {leaves.map((l) => (
              <TableRow key={l.id}>
                {role === "admin" && <TableCell>{l.employees?.full_name}</TableCell>}
                <TableCell className="capitalize">{l.leave_type}</TableCell>
                <TableCell>{l.start_date}</TableCell>
                <TableCell>{l.end_date}</TableCell>
                <TableCell>{l.days}</TableCell>
                <TableCell className="max-w-xs truncate text-muted-foreground">{l.reason}</TableCell>
                <TableCell><span className={`rounded-full px-2 py-0.5 text-xs capitalize ${statusColor[l.status]}`}>{l.status}</span></TableCell>
                {role === "admin" && (
                  <TableCell className="space-x-1">
                    {l.status === "pending" && <>
                      <Button size="icon" variant="ghost" onClick={() => decide(l.id, "approved")}><Check className="size-4 text-success" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => decide(l.id, "rejected")}><X className="size-4 text-destructive" /></Button>
                    </>}
                  </TableCell>
                )}
              </TableRow>
            ))}
            {leaves.length === 0 && <TableRow><TableCell colSpan={role === "admin" ? 8 : 6} className="py-12 text-center text-muted-foreground">No leaves yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
